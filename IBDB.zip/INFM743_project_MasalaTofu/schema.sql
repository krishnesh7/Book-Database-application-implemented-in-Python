DROP TABLE IF EXISTS publisher;
DROP TABLE IF EXISTS category;
DROP TABLE IF EXISTS book;
DROP TABLE IF EXISTS image;
DROP TABLE IF EXISTS book_image;
DROP TABLE IF EXISTS doc;
DROP TABLE IF EXISTS book_doc;
DROP TABLE IF EXISTS author;
DROP TABLE IF EXISTS book_author;
DROP TABLE IF EXISTS book_seller;
DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS user_user;
DROP TABLE IF EXISTS user_book;
DROP TABLE IF EXISTS comment;
DROP TABLE IF EXISTS helpful;
DROP TABLE IF EXISTS newbook;



CREATE TABLE publisher (
publisherID integer PRIMARY KEY autoincrement,
name varchar(255) NOT NULL, 
city varchar(255),
country varchar(255)
);


CREATE TABLE category (
categoryID integer PRIMARY KEY autoincrement,
name varchar(255) NOT NULL
);



CREATE TABLE book (
bookID integer PRIMARY KEY autoincrement,
title varchar(255) NOT NULL,
ISBN13 int(13),
pub_year int(4),
pages int,
publisherID int NOT NULL,
categoryID int NOT NULL,
introduction text,
contents text,
CONSTRAINT FK_book_publisher_publisherID FOREIGN KEY (publisherID) REFERENCES publisher (publisherID) ON DELETE NO ACTION ON UPDATE NO ACTION,
CONSTRAINT FK_book_category_categoryID FOREIGN KEY (categoryID) REFERENCES category (categoryID) ON DELETE NO ACTION ON UPDATE NO ACTION
);




CREATE TABLE image (
imageID integer PRIMARY KEY autoincrement,
url text NOT NULL,
type varchar(30) NOT NULL
);

CREATE TABLE book_image (
bookID int NOT NULL,
imageID int NOT NULL,
cover int(1),
CONSTRAINT [PK_book_image] PRIMARY KEY  (bookID, imageID),
CONSTRAINT FK_book_image_bookID FOREIGN KEY (bookID) REFERENCES book (bookID) ON DELETE NO ACTION ON UPDATE NO ACTION,
CONSTRAINT FK_book_image_imageID FOREIGN KEY (imageID) REFERENCES image (imageID) ON DELETE NO ACTION ON UPDATE NO ACTION
);



CREATE TABLE doc (
docID integer PRIMARY KEY autoincrement,
url text NOT NULL,
type varchar(30) NOT NULL
);


CREATE TABLE book_doc (
bookID int NOT NULL,
docID int NOT NULL,
CONSTRAINT [PK_book_doc] PRIMARY KEY  (bookID, docID),
CONSTRAINT FK_book_doc_bookID FOREIGN KEY (bookID) REFERENCES book (bookID) ON DELETE NO ACTION ON UPDATE NO ACTION,
CONSTRAINT FK_book_doc_docID FOREIGN KEY (docID) REFERENCES doc (docID) ON DELETE NO ACTION ON UPDATE NO ACTION
);



CREATE TABLE author (
authorID integer PRIMARY KEY autoincrement,
name varchar(255) NOT NULL,
imageID int,
url text,
introduction text,
CONSTRAINT FK_author_image_imageID FOREIGN KEY (imageID) REFERENCES image (imageID) ON DELETE NO ACTION ON UPDATE NO ACTION
);


CREATE TABLE book_author (
bookID int NOT NULL,
authorID int NOT NULL,
CONSTRAINT [PK_book_author] PRIMARY KEY  (bookID, authorID),
CONSTRAINT FK_book_author_bookID FOREIGN KEY (bookID) REFERENCES book (bookID) ON DELETE NO ACTION ON UPDATE NO ACTION,
CONSTRAINT FK_book_author_authorID FOREIGN KEY (authorID) REFERENCES author (authorID) ON DELETE NO ACTION ON UPDATE NO ACTION
);



CREATE TABLE user (
userID integer PRIMARY KEY autoincrement,
user_name varchar(70) NOT NULL,
email varchar(70) NOT NULL,
user_password varchar(70) NOT NULL,
user_type int(1) NOT NULL,
introduction text,
imageID int,
CONSTRAINT FK_user_image_imageID FOREIGN KEY (imageID) REFERENCES image (imageID) ON DELETE NO ACTION ON UPDATE NO ACTION
);



CREATE TABLE user_user (
userID1 int NOT NULL,
userID2 int NOT NULL,
CONSTRAINT [PK_user_user] PRIMARY KEY  (userID1, userID2),
CONSTRAINT FK_userID1 FOREIGN KEY (userID1) REFERENCES user (userID) ON DELETE NO ACTION ON UPDATE NO ACTION ,
CONSTRAINT FK_userID2 FOREIGN KEY (userID2) REFERENCES user (userID) ON DELETE NO ACTION ON UPDATE NO ACTION
);


CREATE TABLE user_book (
userID int NOT NULL,
bookID int NOT NULL,
CONSTRAINT [PK_user_book] PRIMARY KEY  (userID, bookID),
CONSTRAINT FK_user_book_userID FOREIGN KEY (userID) REFERENCES user (userID) ON DELETE NO ACTION ON UPDATE NO ACTION ,
CONSTRAINT FK_user_book_bookID FOREIGN KEY (bookID) REFERENCES book (bookID) ON DELETE NO ACTION ON UPDATE NO ACTION
);




CREATE TABLE book_seller (
ID integer PRIMARY KEY autoincrement,
bookID int NOT NULL,
seller_name varchar(255),
seller_url text NOT NULL,
CONSTRAINT FK_seller_book_bookID FOREIGN KEY (bookID) REFERENCES book (bookID) ON DELETE NO ACTION ON UPDATE NO ACTION 
);




CREATE TABLE comment (
commentID integer PRIMARY KEY autoincrement, 
bookID int NOT NULL,
userID int NOT NULL,
comment_date datetime NOT NULL, 
score int(1) NOT NULL,
comment_title text,
comment_text text,
points int DEFAULT 0,
CONSTRAINT FK_comment_book_bookID FOREIGN KEY (bookID) REFERENCES book (bookID) ON DELETE NO ACTION ON UPDATE NO ACTION ,
CONSTRAINT FK_comment_user_userID FOREIGN KEY (userID) REFERENCES user (userID) ON DELETE NO ACTION ON UPDATE NO ACTION
);


CREATE TABLE helpful (
commentID int NOT NULL,
userID int NOT NULL,
CONSTRAINT [PK_helpful] PRIMARY KEY  (commentID, userID),
CONSTRAINT FK_comment_helpful_commentID FOREIGN KEY (commentID) REFERENCES comment (commentID) ON DELETE NO ACTION ON UPDATE NO ACTION ,
CONSTRAINT FK_user_helpful_userID FOREIGN KEY (userID) REFERENCES user (userID) ON DELETE NO ACTION ON UPDATE NO ACTION
);



CREATE TABLE newbook (
bookID integer PRIMARY KEY autoincrement,
userID int NOT NULL,
title varchar(255) NOT NULL,
author text,
introduction text,
ISBN13 int(13),
pub_year int(4),
pages int,
publisherID int,
publisher varchar(255),
categoryID int,
category varchar(255),
CONSTRAINT FK_new_user_userID FOREIGN KEY (userID) REFERENCES user (userID) ON DELETE NO ACTION ON UPDATE NO ACTION,
CONSTRAINT FK_new_publisher_publisherID FOREIGN KEY (publisherID) REFERENCES publisher (publisherID) ON DELETE NO ACTION ON UPDATE NO ACTION,
CONSTRAINT FK_new_category_categoryID FOREIGN KEY (categoryID) REFERENCES category (categoryID) ON DELETE NO ACTION ON UPDATE NO ACTION
);









INSERT INTO publisher (publisherID, name, city, country)
VALUES (1, "O'Reilly Media", "Sebastopol, California", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (2, "Feiwel & Friends", "Los Anageles, California", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (3, "Putnam Juvenile", "Washington, DC", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (4, "Atheneum/Richard Jackson Books", "Pittsburgh, PA", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (5, "Chronicle Books", "San Francisco, California", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (6, "HarperCollins", "New York, New York,", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (7, "Abingdon Press", "Nashville, Tennessee", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (8, "Prospecta Press", "New York, New York", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (9, "AmazonCrossing", "Amzon official website", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (10, "Putnam Adult", "New York, New York", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (11, "Crown Business", "New York, New York", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (12, "Basic Books", "New York, New York", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (13, "Wiley", "Hoboken, NJ ", "United States");
INSERT INTO publisher (publisherID, name, city, country)
VALUES (14, "Wiley", "Hoboken, NJ ", "United States");





INSERT INTO category (categoryID, name) VALUES (1, "Science and Technology");
INSERT INTO category (categoryID, name) VALUES (2, "Children");
INSERT INTO category (categoryID, name) VALUES (3, "Fiction");
INSERT INTO category (categoryID, name) VALUES (4, "Art");
INSERT INTO category (categoryID, name) VALUES (5, "Business");
INSERT INTO category (categoryID, name) VALUES (6, "Romance");
INSERT INTO category (categoryID, name) VALUES (7, "Cooking");




INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (1, "Head First HTML5 Programming", 9781449390549, 2011, 610, 1, 1, 
	"Head First HTML5 Programming is your ultimate tour guide to creating web applications with HTML5 and JavaScript, and we give you everything you need to know to build them, including: how to add interactivity to your pages, how to communicate with the world of Web services, and how to use the great new APIs being developed for HTML5.", 
	"table of contents");
INSERT INTO book ( bookID, 
	title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (2, "Head First JavaScript Programming", 9781449340131, 2014, 704, 1, 1,
	"This brain-friendly guide teaches you everything from JavaScript language fundamentals to advanced topics, including objects, functions, and the browser’s document object model. You won’t just be reading—you’ll be playing games, solving puzzles, pondering mysteries, and interacting with JavaScript in ways you never imagined. And you’ll write real code, lots of it, so you can start building your own web applications. ",
	"contents");

INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (3, "Rain Reign", 312643004, 2014, 240, 2, 2,
	"Rose Howard is obsessed with homonyms. She’s thrilled that her own name is a homonym, and she purposely gave her dog Rain a name with two homonyms (Reign, Rein), which, according to Rose’s rules of homonyms, is very special. Not everyone understands Rose’s obsessions, her rules, and the other things that make her different – not her teachers, not other kids, and not her single father.

When a storm hits their rural town, rivers overflow, the roads are flooded, and Rain goes missing. Rose’s father shouldn’t have let Rain out. Now Rose has to find her dog, even if it means leaving her routines and safe places to search.

Hearts will break and spirits will soar for this powerful story, brilliantly told from Rose’s point of view.",
	"contents");

INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (4, "Pennyroyal Academ", 399163247, 2014, 304, 3, 2,
	"A girl from the forest arrives in a bustling kingdom with no name and no idea why she is there, only to find herself at the center of a world at war.  She enlists at Pennyroyal Academy, where princesses and knights are trained to battle the two great menaces of the day: witches and dragons. There, given the name “Evie,” she must endure a harsh training regimen under the steel glare of her Fairy Drillsergeant, while also navigating an entirely new world of friends and enemies. As Evie learns what it truly means to be a princess, she realizes surprising things about herself and her family, about human compassion and inhuman cruelty. And with the witch forces moving nearer, she discovers that the war between princesses and witches is much more personal than she could ever have imagined."
	,"contents");

INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (5, "Locomotive", 1416994157, 2013, 64, 4, 2,
	" The Caldecott Medal Winner, Sibert Honor Book, and New York Times bestseller Locomotive is a rich and detailed sensory exploration of America’s early railroads, from the creator of the “stunning” (Booklist) Moonshot.

It is the summer of 1869, and trains, crews, and family are traveling together, riding America’s brand-new transcontinental railroad. These pages come alive with the details of the trip and the sounds, speed, and strength of the mighty locomotives; the work that keeps them moving; and the thrill of travel from plains to mountain to ocean.

Come hear the hiss of the steam, feel the heat of the engine, watch the landscape race by. Come ride the rails, come cross the young country!",
	"contents");
INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (6, "Flora and the Flamingo", 1452110069, 2013, 44, 5, 2,
	"In this innovative wordless picture book with interactive flaps, Flora and her graceful flamingo friend explore the trials and joys of friendship through an elaborate synchronized dance. With a twist, a turn, and even a flop, these unlikely friends learn at last how to dance together in perfect harmony. Full of humor and heart, this stunning performance (and splashy ending!) will have readers clapping for more!",
	"contents");
INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (7, "The One and Only lvan", 61992259, 2012, 320, 6, 2,
	"Winner of the 2013 Newbery Medal and a #1 New York Times bestseller, this stirring and unforgettable novel from renowned author Katherine Applegate celebrates the transformative power of unexpected friendships. Inspired by the true story of a captive gorilla known as Ivan, this illustrated novel is told from the point-of-view of Ivan himself.Having spent 27 years behind the glass walls of his enclosure in a shopping mall, Ivan has grown accustomed to humans watching him. He hardly ever thinks about his life in the jungle. Instead, Ivan occupies himself with television, his friends Stella and Bob, and painting. But when he meets Ruby, a baby elephant taken from the wild, he is forced to see their home, and his art, through new eyes.",
	"contents");
INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (8, "Seeds of Evidence", 1426735421, 2013, 320, 7, 3,
    "Shaken by an unwanted divorce, FBI Special Agent Kit McGovern retreats to her grandmother’s Virginia island home for a little R & R. But her vacation comes to an unexpected end when the body of a young Latino boy is found on the beach.
Kit teams up with D.C. cop David O’Connor to investigate the murder with the smallest of clues—tomato seeds and acorns found in the boy’s pockets. Using plant DNA evidence, Kit traces the young boy to a huge farm where more than a killer looms. With grit, determination, and a growing interest in David, Kit pursues her case and discovers that, to truly move forward in life, justice has to be tempered with mercy.",
    "contents");

INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (9, "The Paris Herald: A Novel", 1935212322, 2014, 304, 8, 3, 
	"The story centers on intrigue and rivalry among the New York Herald Tribune, New York Times and Washington Post. When the Herald Tribune ceased operations in New York in 1966, the Times, which had started its own European Edition in 1960, expected the Paris Herald to close, too, giving the Times victory in Paris as well as New York. But Herald Tribuneowner Jock Whitney wouldn’t sell to the Times, preferring to join with Katharine Graham, who’d taken charge at the Post after her husband’s death.
Within months, the Times came, hat-in-hand, offering to close its European edition and asking to buy into the new Herald/Post partnership. The Times neither forgave nor forgot its humiliation.
The Paris Herald is the story of many people: of Frank Draper, who fought in the Lincoln Brigade; Byron Hallsberg, who joined the Hungarian uprising; Dennis Klein, researching the Nazi occupation of Paris; Suzy de Granville, searching for family roots; Wayne Murray, escaping homophobia; of Steve and Molly Fleming, living the high life; Sonny Stein and Al Lodge and Connie Marshall and Ben Swart and Eddie Jones, paperboy, all finding themselves at the Paris Herald for their own reasons and ending up in the fight to keep the newspaper alive.
The 1960s was a tumultuous decade.the Paris Herald has been essential to American expatriate life in Europe. In France, many Americans put down roots, married into French families and became permanent expatriates, in some cases exiles, like Bennett himself. The tense events of the 1960s touched the lives of every American in Paris, including many well-known artistic exiles: James Baldwin, Art Buchwald, William Saroyan, James Jones, Bud Powell, Dexter Gordon, Kenny Clarke, Joe Turner, Memphis Slim.
As the crisis deepened, one shadowy man became the link between de Gaulle and the troika of newspaper owners, Whitney, Graham and Arthur Ochs Sulzberger. This man, Henri de Saint-Gaudens, a high French official in the Elysée Palace, understood the Herald’s historical importance to Paris.
The Paris Herald, a novel, is riveting historical drama, as relevant today as yesterday. It is a story never before told.",
	"contents");
INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (10, "The Glassblower", 1477820272, 2014, 498, 9 , 3, 
	"In the village of Lauscha in Germany, things have been done the same way for centuries. The men blow the glass, and the women decorate and pack it. But when Joost Steinmann passes away unexpectedly one September night, his three daughters must learn to fend for themselves. While feisty Johanna takes a practical approach to looking for work, Ruth follows her heart, aiming to catch the eye of a handsome young villager. But it is dreamy, quiet Marie who has always been the most captivated by the magic—and sparkling possibilities—of the craft of glassblowing. As the spirited sisters work together to forge a brighter future for themselves on their own terms, they learn not only how to thrive in a man’s world, but how to remain true to themselves—and their hearts—in the process.",
    "contents");
INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (11, "The Fallen: A Derek Stillwater Thriller", 1933515759, 2010, 288, 9, 3, 
	"Twenty world leaders meet for the G8 Summit at the beautiful Cheyenne Resort in Colorado Springs. But an ugly plot lurks beneath the surface: a terrorist group, The Fallen Angels, plans to wreak havoc on the Summit.With the Secret Service, the FBI, Homeland Security, the military, and security from twenty different governments on-hand, shouldn't the resort be the safest place in the world?It seems impossible that a terrorist group could infiltrate the Summit. And yet they do. Within minutes, twenty world leaders are taken hostage, and Richard Coffee, the group's leader, makes his first demand: release twenty detainees from Guantanamo Bay, or he'll execute one leader each hour until his demands are met.Only one man can disrupt this plot. Derek Stillwater is that man.Working undercover as a maintenance man at the resort, Stillwater will wage war on the world's deadliest, most sophisticated terrorist organization, picking off the terrorists one by one-until he comes face-to-face with an evil force from his past, Richard Coffee, The Fallen Angel himself.",
	"contents");
INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (12, "Havana Storm (Dirk Pitt Adventure)", 399172920, 2014, 453, 10, 3, 
	"Dirk Pitt returns, in the thrilling new novel from the grand master of adventure and #1 New York Times–bestselling author.
While investigating a toxic outbreak in the Caribbean Sea that may ultimately threaten the United States, Pitt unwittingly becomes involved in something even more dangerous—a post-Castro power struggle for the control of Cuba. Meanwhile, Pitt’s children, marine engineer Dirk and oceanographer Summer, are on an investigation of their own, chasing an Aztec stone that may reveal the whereabouts of a vast historical Aztec treasure. The problem is, that stone was believed to have been destroyed on the battleship Maine in Havana Harbor in 1898, which brings them both to Cuba as well—and squarely into harm’s way. The three of them have been in desperate situations before . . . but perhaps never quite as dire as the one facing them now. ",
    "contents");

INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (13, "Why Nations Fail: The Origins of Power, Prosperity, and Poverty", 307719227, 2013, 544, 11, 5, 
	"Is it culture, the weather, geography? Perhaps ignorance of what the right policies are? 

Simply, no. None of these factors is either definitive or destiny. Otherwise, how to explain why Botswana has become one of the fastest growing countries in the world, while other African nations, such as Zimbabwe, the Congo, and Sierra Leone, are mired in poverty and violence? 

Daron Acemoglu and James Robinson conclusively show that it is man-made political and economic institutions that underlie economic success (or lack of it). Korea, to take just one of their fascinating examples, is a remarkably homogeneous nation, yet the people of North Korea are among the poorest on earth while their brothers and sisters in South Korea are among the richest. The south forged a society that created incentives, rewarded innovation, and allowed everyone to participate in economic opportunities. The economic success thus spurred was sustained because the government became accountable and responsive to citizens and the great mass of people. Sadly, the people of the north have endured decades of famine, political repression, and very different economic institutions—with no end in sight. The differences between the Koreas is due to the politics that created these completely different institutional trajectories. 

Based on fifteen years of original research Acemoglu and Robinson marshall extraordinary historical evidence from the Roman Empire, the Mayan city-states, medieval Venice, the Soviet Union, Latin America, England, Europe, the United States, and Africa to build a new theory of political economy with great relevance for the big questions of today, including: 

   - China has built an authoritarian growth machine. Will it continue to grow at such high speed and overwhelm the West? 
   - Are America’s best days behind it? Are we moving from a virtuous circle in which efforts by elites to aggrandize power are resisted to a vicious one that enriches and empowers a small minority? 
   - What is the most effective way to help move billions of people from the rut of poverty to prosperity? More 
philanthropy from the wealthy nations of the West? Or learning the hard-won lessons of Acemoglu and Robinson’s breakthrough ideas on the interplay between inclusive political and economic institutions? 

Why Nations Fail will change the way you look at—and understand—the world.",
    "contents");


INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (14, "Basic Economics: A Common Sense Guide to the Economy", 465022529, 2010, 786, 12, 5, 
	"The fourth edition of Basic Economics is both expanded and updated. A new chapter on the history of economics itself has been added, and the implications of that history examined. A new section on the special role of corporations in the economy has been added to the chapter on government and big business, among other additions throughout the book.
Basic Economics, which has now been translated into six languages, has grown so much that a large amount of material in the back of the book in previous editions has now been put online instead, so the book itself and its price will not have to expand. The central idea of Basic Economics, however, remains the same: that the fundamental facts and principles of economics do not require jargon, graphs, or equations, and can be learned in a relaxed and even enjoyable way.",
    "contents");
INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (15, "China's Super Consumers: What 1 Billion Customers Want and How to Sell it to Them", 118834747, 2014, 240, 13, 5,
	"Chinese Consumers are Changing The World – Understand Them and Sell To Them
China has transformed itself from a feudal economy in the 19th century, to Mao and Communism in the 20th century, to the largest consumer market in the world by the early 21st century. China's Super Consumers explores the extraordinary birth of consumerism in China and explains who these super consumers are. China's Super Consumers offers an in-depth explanation of what's inside the minds of Chinese consumers and explores what they buy, where they buy, how they buy, and most importantly why they buy.",
"contents");

INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents)
VALUES (16, "Econometrics For Dummies", 118533844, 2013, 360, 14, 5,
    "Econometrics can prove challenging for many students unfamiliar with the terms and concepts discussed in a typical econometrics course. Econometrics For Dummies eliminates that confusion with easy-to-understand explanations of important topics in the study of economics.
Econometrics For Dummies breaks down this complex subject and provides you with an easy-to-follow course supplement to further refine your understanding of how econometrics works and how it can be applied in real-world situations.",
"contents");


/*INSERT INTO book ( bookID, title, ISBN13, pub_year, pages, publisherID, categoryID, introduction, contents) 
VALUES (17，"When Money Dies: The Nightmare of Deficit Spending, Devaluation, and Hyperinflation in Weimar Germany ", 1586489941, 2010, 360, 11, 5,"When Money Dies is the classic history of what happens when a nation;s currency depreciates beyond recovery ", "contents");
*/

INSERT INTO image (imageID, url, type) VALUES (1, "/static/image/book/1.jpg", "book");
INSERT INTO image (imageID, url, type) VALUES (2, "/static/image/book/2.jpg", "book");
INSERT INTO image (imageID, url, type) VALUES (9, "/static/image/book/rainreign.png", "book");
INSERT INTO image (imageID, url, type) VALUES (10, "/static/image/book/pennyroyalacademy.png", "book");
INSERT INTO image (imageID, url, type) VALUES (11, "/static/image/book/Locomotive.png", "book");
INSERT INTO image (imageID, url, type) VALUES (12, "/static/image/book/FloraandtheFlamingo.png", "book");
INSERT INTO image (imageID, url, type) VALUES (13, "/static/image/book/TheOneAndOnlyIvan.png", "book");
INSERT INTO image (imageID, url, type) VALUES (14, "/static/image/book/SeedsOfEvidence.png", "book");
INSERT INTO image (imageID, url, type) VALUES (15, "/static/image/book/Paris_herald.jpg", "book");
INSERT INTO image (imageID, url, type) VALUES (16, "/static/image/book/TheGlassblower.png", "book");
INSERT INTO image (imageID, url, type) VALUES (17, "/static/image/book/TheFallen.png", "book");
INSERT INTO image (imageID, url, type) VALUES (18, "/static/image/book/HavanaStorm.png", "book");
INSERT INTO image (imageID, url, type) VALUES (19, "/static/image/book/WhyNationsFail.png", "book");
INSERT INTO image (imageID, url, type) VALUES (20, "/static/image/book/BasicEconomics.png", "book");
INSERT INTO image (imageID, url, type) VALUES (21, "/static/image/book/ChinaSuper.png", "book");
INSERT INTO image (imageID, url, type) VALUES (22, "/static/image/book/EconometricsForDummies.png", "book");
INSERT INTO image (imageID, url, type) VALUES (23, "/static/image/book/WhyMoneyDies.png", "book");


INSERT INTO image (imageID, url, type) VALUES (3, "/static/image/author/Eric Freeman.jpg", "author");
INSERT INTO image (imageID, url, type) VALUES (4, "/static/image/author/Elisabeth Robson.jpg", "author");
INSERT INTO image (imageID, url, type) VALUES (24, "/static/image/author/Ann.png", "author");
INSERT INTO image (imageID, url, type) VALUES (25, "/static/image/author/Larson.png", "author");
INSERT INTO image (imageID, url, type) VALUES (26, "/static/image/author/brianfloca.png", "author");
INSERT INTO image (imageID, url, type) VALUES (27, "/static/image/author/Idle.png", "author");
INSERT INTO image (imageID, url, type) VALUES (28, "/static/image/author/Applegate.png", "author");
INSERT INTO image (imageID, url, type) VALUES (29, "/static/image/author/Linda.png", "author");
INSERT INTO image (imageID, url, type) VALUES (30, "/static/image/author/James.png", "author");
INSERT INTO image (imageID, url, type) VALUES (31, "/static/image/author/Petra.png", "author");
INSERT INTO image (imageID, url, type) VALUES (32, "/static/image/author/Mark.png", "author");
INSERT INTO image (imageID, url, type) VALUES (33, "/static/image/author/Clive.png", "author");
INSERT INTO image (imageID, url, type) VALUES (34, "/static/image/author/Charles.png", "author");
INSERT INTO image (imageID, url, type) VALUES (35, "/static/image/author/Thomas.png", "author");
INSERT INTO image (imageID, url, type) VALUES (36, "/static/image/author/Savio.png", "author");
INSERT INTO image (imageID, url, type) VALUES (37, "/static/image/author/Roberto.png", "author");
INSERT INTO image (imageID, url, type) VALUES (38, "/static/image/author/Adam.png", "author");


INSERT INTO image (imageID, url, type) VALUES (5, "/static/image/user/f1.png", "user");
INSERT INTO image (imageID, url, type) VALUES (6, "/static/image/user/f2.png", "user");
INSERT INTO image (imageID, url, type) VALUES (7, "/static/image/user/m1.png", "user");
INSERT INTO image (imageID, url, type) VALUES (8, "/static/image/user/m2.png", "user");





INSERT INTO book_image (bookID, imageID, cover) values (1, 1, 1);
INSERT INTO book_image (bookID, imageID, cover) values (2, 2, 1);
INSERT INTO book_image (bookID, imageID, cover) values (3, 9, 1);
INSERT INTO book_image (bookID, imageID, cover) values (4, 10, 1);
INSERT INTO book_image (bookID, imageID, cover) values (5, 11, 1);
INSERT INTO book_image (bookID, imageID, cover) values (6, 12, 1);
INSERT INTO book_image (bookID, imageID, cover) values (7, 13, 1);
INSERT INTO book_image (bookID, imageID, cover) values (8, 14, 1);
INSERT INTO book_image (bookID, imageID, cover) values (9, 15, 1);
INSERT INTO book_image (bookID, imageID, cover) values (10, 16, 1);
INSERT INTO book_image (bookID, imageID, cover) values (11, 17, 1);
INSERT INTO book_image (bookID, imageID, cover) values (12, 18, 1);
INSERT INTO book_image (bookID, imageID, cover) values (13, 19, 1);
INSERT INTO book_image (bookID, imageID, cover) values (14, 20, 1);
INSERT INTO book_image (bookID, imageID, cover) values (15, 21, 1);
INSERT INTO book_image (bookID, imageID, cover) values (16, 22, 1);



INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (1, "Eric Freeman", 3, "http://www.oreilly.com/pub/au/2003", "Eric Freeman is described by Head First series co-creator Kathy Sierra as 'one of those rare individuals fluent in the language, practice, and culture of multiple domains from hipster hacker, to corporate VP, engineer, think tank.' Professionally, Eric recently ended nearly a decade as a media company executive, having held the position ofCTO of Disney Online & Disney.com at The Walt Disney Company. Eric is now devoting his time to WickedlySmart.com and lives with his wife and young daughter on Bainbridge Island. He holds a Ph.D. in Computer Science from Yale University.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (2, "Elisabeth Robson", 4, "http://www.oreilly.com/pub/au/2002", "Elisabeth Robson is co-founder of Wickedly Smart, an education company devoted to helping customers gain mastery in web technologies. She’s co-author of two bestselling books, Head First Design Patterns and Head First HTML with CSS & XHTML.");

INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (3, "Ann M.Martin", 24, "http://en.wikipedia.org/wiki/Ann_M._Martin", "Ann Matthews Martin (born August 12, 1955) is an American children's author.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (4, "M.A. Larson", 25, "http://www.goodreads.com/author/show/7855154.M_A_Larson", "M.A. Larson is a film and television writer who lives with his wife, daughter, and two dogs in a canyon in California.  Larson has written for Cartoon Network, Disney Channel, Disney XD, Disney UK, Discovery Kids Channel, The Hub, and Nickelodeon. As a writer on the cult sensation My Little Pony: Friendship is Magic, he has been a guest at “brony” fan conventions from Paris, France to Dallas, Texas. This is his first novel. Larson can be found on twitter at @M_A_Larson, where he frequently tweets about classic films and magical candy-colored ponies.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (5, "Brian Floca", 26, "http://brianfloca.com/About.html", "Brian Floca's picture books include Locomotive winner of the 2014 Caldecott Medal, a Robert F. Sibert Honor Book, and a New York Times 10 Best Illustrated Books of 2013 selection; Moonshot: The Flight of Apollo 11, also a Sibert Honor Book and New York Times Best Illustrated Book; Lightship a Sibert Honor Book; ");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (6, "Molly Idle", 27, "http://idleillustration.com/about/", "Molly Idle has been drawing ever since she could wield a pencil. But while she started scribbling before she could walk, her professional career as an artist began slightly later");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (7, "Katherine Applegate", 28, "http://theoneandonlyivan.com/author/", "Katherine Applegate's many books include the Roscoe Riley Rules chapter book series, a picture book entitled The Buffalo Storm, and the award-winning novel, Home of the Brave. With her husband, Michael Grant, she wrote the hugely popular series Animorphs, which has sold more than 35 million copies worldwide.
Katherine was inspired to write The One and Only Ivan after reading about the true story of a captive gorilla known as Ivan, the ""Shopping Mall Gorilla."" The real Ivan lived alone in a tiny cage for twenty-seven years at a shopping mall before being moved to Zoo Atlanta after a public outcry. He was a beloved celebrity at the zoo, which houses the nation's largest collection of western lowland gorillas, and was well known for his paintings, which he ""signed"" with a thumb-print.
Katherine lives in California with her husband and two children.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (8, " Linda J. White", 29, "http://www.lindajwhite.com/", "Linda J. White writes white-knuckle fiction, FBI thrillers with a twist of faith (shaken, not stirred). Her goal in life is to keep readers up all night turning pages. Born in Washington, D.C., her great aunt dated J. Edgar Hoover. A national-award winning journalist, Linda lives in rural Virginia now, near the FBI Academy where her husband worked for 27 years. They have three grown kids, two grandkids, two cats, and a Sheltie who tries to keep everyone moving in the same direction. When she's not writing, Linda loves being with her family, at the beach, or doing something (anything) with dogs.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (9, "James Oliver Goldsborough", 30, "http://jamesogoldsborough.com/", "James Oliver Goldsborough (born 1936) is an American journalist and author, born in New York City of a family with roots in Pittsburgh. Brought up in Los Angeles, he graduated from UCLA with a degree in economics. After serving two years in the U.S. Army he attended UC Berkeley Law School and Mexico City College.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (10, "Petra Durst-Benning", 31, "http://www.goodreads.com/author/show/754977.Petra_Durst_Benning", "Petra Durst-Benning has developed a loyal following for her well-researched historical novels in her native Germany, where she lives with her husband. She has written more than a dozen books, many of which have gone on to be bestsellers. Durst-Benning’s love of the US dates back many years. She visited frequently as a child and developed a passion for American bestsellers, which went on to inspire her own writing career in later years. The Glassblower’s English-language debut is, in many ways, the fulfillment of a girlhood dream.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (11, "Mark Terry", 32, "http://www.markterrybooks.com/", "Mark Terry is the author of the Derek Stillwater thrillers, THE DEVIL'S PITCHFORK, THE SERPENT'S KISS, and THE FALLEN, as well as several standalone thrillers, including DIRTY DEEDS, CATFISH GURU, and DANCING IN THE DARK. Born in Flint, Michigan in 1964, he graduated from Michigan State University with a degree in microbiology and public health, which has informed his Derek Stillwater thrillers and other fiction. After spending 18 years working in clinical genetics, he turned to writing full time. When not writing or reading, Mark Terry is a gym rat, lifting weights, biking, running, kayaking, studying Sanchin-Ryu karate, and playing the guitar. Otherwise he spends his time with his wife and two sons in Michigan.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (12, "Clive Cussler", 33, "http://www.clive-cussler-books.com/", "Clive Cussler is the author of dozens of New York Times bestsellers, most recently Ghost Ship and The Eye of Heaven. He lives in Arizona.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (13, "Charles C. Mann", 34, "http://www.charlesmann.org/", "Charles C. Mann, a correspondent for The Atlantic, Science, and Wired, has written for Fortune, The New York Times, Smithsonian, Technology Review, Vanity Fair, and The Washington Post, as well as for the TV network HBO and the series Law & Order. A three-time National Magazine Award finalist, he is the recipient of writing awards from the American Bar Association, the American Institute of Physics, the Alfred P. Sloan Foundation, and the Lannan Foundation. His 1491 won the National Academies Communication Award for the best book of the year. He lives in Amherst, Massachusetts.
A few years ago, while I was researching a book on the history of globalization, I suddenly realized that I was seeing the same two names on a lot of the smartest stuff I was reading. The names belonged to two economists, Daron Acemoglu and James Robinson. Much of their work focused on a single question: Why are poor places poor, and is there something we can do about it?
This is one of the most important questions imaginable in economics—indeed, in the world today. It is also one of the most politically fraught. In working on my book, I read numerous attempts by economists, historians and other researchers to explain why most of North America and Europe is wealthy and why most of Asia, Africa and Latin America is not. But these usually boiled down to claims that rich nations had won the game by cheating poor places or that poor places had inherently inferior cultures (or locations) which prevented them from rising. Conservative economists used the discussion as a chance to extol the wide-open markets they already believed in; liberal economists used it to make the attacks on unrestrained capitalism they were already making. And all too often both seemed wildly ignorant of history. I can’t recall encountering another subject on which so many people expended so much energy to generate so little light.
Acemoglu and Robinson were in another category entirely. They assembled what is, in effect, a gigantic, super-complete database of every country’s history, and used it to ask questions—wicked smart questions. They found unexpected answers—ones that may not satisfy partisans of either side, but have the ring of truth.
Why Nations Fail is full of astounding stories. I ended up carrying the book around, asking friends, “Did you know this?” The stories make it a pleasure to read. More important, though, Acemoglu and Robinson changed my perspective on how the world works. My suspicion is that I won’t be the only person to say this after reading Why Nations Fail.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (14, "Thomas Sowell", 35, "http://www.tsowell.com/", "Thomas Sowell has taught economics at Cornell, UCLA, Amherst and other academic institutions, and his Basic Economics has been translated into six languages. He is currently a scholar in residence at the Hoover Institution, Stanford University. He has published in both academic journals in such popular media as the Wall Street Journal, Forbes magazine and Fortune, and writes a syndicated column that appears in newspapers across the country.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (15, "Savio Chan", 36, "http://fsmweb.northwestern.edu/faculty/facultyProfile.cfm?xid=17849", "Savio S. Chan is a preeminent expert on US-China partnerships and building loyalty with Chinese luxury consumers. He serves as President and Chief Executive Officer of US China Partners Inc., a consulting and advisory firm that helps organization designs and implements their China consumers' strategies. He spent two decades as a consultant on market entry, cross-border M&A and joint ventures partnership innovation with some of the largest and well-known global luxury and consumer brands, Fortune 500 and Chinese large State-Own and private companies.
He is frequently featured in interviews and articles in the New York Times, Forbes, Chief Executive Magazine and China Daily News. Savio serves as a member of National Committee on US-China Relations and advises many ultra-high net worth legacy families in both the US and China. He is a frequent keynote speaker and panelist at various business and technology events including the Conference Board, Microsoft Technology Conference, Columbia China Conference and Wharton China Business Forum.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (16, "Roberto Pedace", 37, "http://www.cgu.edu/pages/4375.asp", "Roberto Pedace, PhD, is an associate professor in the Department of Economics at Scripps College. His published work has appeared in Economic Inquiry, Industrial Relations, the Southern Economic Journal, Contemporary Economic Policy, the Journal of Sports Economics, and other outlets.");
INSERT INTO author (authorID, name, imageID, url, introduction)
VALUES (17, "Adam Fergusson", 38, "http://www.financialsense.com/contributors/adam-fergusson/interview-when-money-dies-weimar-germany", "Adam Dugdale Fergusson (born 10 July 1932) is a British journalist, author and Conservative Party politician who served one term in the European Parliament (MEP).");





INSERT INTO book_author (bookID, authorID) VALUES (1, 1);
INSERT INTO book_author (bookID, authorID) VALUES (1, 2);
INSERT INTO book_author (bookID, authorID) VALUES (2, 1);
INSERT INTO book_author (bookID, authorID) VALUES (2, 2);
INSERT INTO book_author (bookID, authorID) VALUES (3, 3);
INSERT INTO book_author (bookID, authorID) VALUES (4, 4);
INSERT INTO book_author (bookID, authorID) VALUES (5, 5);
INSERT INTO book_author (bookID, authorID) VALUES (6, 6);
INSERT INTO book_author (bookID, authorID) VALUES (7, 7);
INSERT INTO book_author (bookID, authorID) VALUES (8, 8);
INSERT INTO book_author (bookID, authorID) VALUES (9, 9);
INSERT INTO book_author (bookID, authorID) VALUES (10, 10);
INSERT INTO book_author (bookID, authorID) VALUES (11, 11);
INSERT INTO book_author (bookID, authorID) VALUES (12, 12);
INSERT INTO book_author (bookID, authorID) VALUES (13, 13);
INSERT INTO book_author (bookID, authorID) VALUES (14, 14);
INSERT INTO book_author (bookID, authorID) VALUES (15, 15);
INSERT INTO book_author (bookID, authorID) VALUES (16, 16);
--INSERT INTO book_author (bookID, authorID) VALUES (17, 17);






INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (1, 1, "O'Reilly", "http://shop.oreilly.com/product/0636920010906.do?CMP=ILC-hf1st");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (2, 1, "Amazon", "http://www.amazon.com/Head-First-HTML5-Programming-JavaScript/dp/1449390544");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (3, 1, "Barnes&Noble", "http://www.barnesandnoble.com/w/head-first-html5-programming-eric-t-freeman/1104952404?ean=9781449390549");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (4, 2, "O'Reilly", "http://shop.oreilly.com/product/0636920027065.do#");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (5, 2, "Amazon", "http://www.amazon.com/Head-First-JavaScript-Programming-Freeman/dp/144934013X/ref=sr_1_1?ie=UTF8&qid=1414595021&sr=8-1&keywords=Head+First+JavaScript+Programming");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (6, 2, "Barnes&Noble", "http://www.barnesandnoble.com/listing/2691705961574?r=1&kpid=2691705961574&cm_mmc=Google%20Product%20Search-_-Q000000633-_-2691705961574PLA-_-Book_45Up-_-Q000000633-_-2691705961574");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (7, 3, "Amazon", "http://www.amazon.com/Rain-Reign-Ann-M-Martin/dp/1491530510");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (8, 3, "Barnes&Noble", "http://www.barnesandnoble.com/w/rain-reign-ann-m-martin/1118139042?ean=9780312643003");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (9, 4, "Amazon", "http://www.amazon.com/Pennyroyal-Academy-M-A-Larson/dp/0399163247");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (10, 4, "Barnes&Noble", "http://www.barnesandnoble.com/w/pennyroyal-academy-ma-larson/1118662998?ean=9780399163241");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (11, 4, "Parnassus", "http://www.parnassusbooks.net/book/9780399163241");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (12, 5, "Amazon", "http://www.amazon.com/Locomotive-Caldecott-Medal-Brian-Floca/dp/1416994157/ref=sr_1_1?s=books&ie=UTF8&qid=1418147333&sr=1-1&keywords=Locomotive&pebp=1418147336791");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (13, 5, "Barnes&Noble", "http://www.barnesandnoble.com/w/locomotive-brian-floca/1114307287?ean=9781416994152");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (14, 5, "Parnassus", "http://www.parnassusbooks.net/book/9781416994152");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (15, 6, "Amazon", "http://www.amazon.com/Flora-Flamingo-Molly-Idle/dp/1452110069/ref=sr_1_1?s=books&ie=UTF8&qid=1418148279&sr=1-1&keywords=Flora+and+the+Flamingo&pebp=1418148281857");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (16, 6, "Barnes&Noble", "http://www.barnesandnoble.com/w/flora-and-the-flamingo-molly-schaar-idle/1111790703?ean=9781452110066&itm=1&usri=9781452110066&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (17, 6, "Ebay", "http://product.half.ebay.com/Flora-and-the-Flamingo-by-Molly-Idle-2013-Hardcover/144067317&cpid=5000029910138");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (18, 7, "Amazon", "http://www.amazon.com/One-Only-Ivan-Katherine-Applegate/dp/0061992259/ref=sr_1_1?s=books&ie=UTF8&qid=1418148554&sr=1-1&keywords=The+One+and+Only+Ivan&pebp=1418148556305");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (19, 7, "Barnes&Noble", "http://www.barnesandnoble.com/w/one-and-only-ivan-katherine-applegate/1102905158?ean=9780061992254&itm=1&usri=9780061992254&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (20, 7, "Ebay", "http://product.half.ebay.com/The-One-and-Only-Ivan-by-Katherine-Applegate-2012-Hardcover/109234159&cpid=5000000396851");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (21, 8, "Amazon", "http://www.amazon.com/Seeds-Evidence-Linda-J-White/dp/1426735421/ref=sr_1_1?s=books&ie=UTF8&qid=1418148693&sr=1-1&keywords=Seeds+of+Evidence&pebp=1418148695450");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (22, 8, "Barnes&Noble", "http://www.barnesandnoble.com/noresults?store=book&pt=bk&ern=210&isbn=1426770820&r=1,%201&cm_mmc=affiliates-_-linkshare-_-gwez7vxblvu-_-10:1");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (23, 8, "Kobo", "http://store.kobobooks.com/en-US/ebook/seeds-of-evidence");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (24, 9, "Amazon", "http://www.amazon.com/gp/product/193521232X/ref=x_gr_w_bb?ie=UTF8&tag=httpwwwgoodco-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=193521232X&SubscriptionId=1MGPYB6YW3HWK55XCGG2");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (25, 9, "Barnes&Noble", "http://www.barnesandnoble.com/w/the-paris-herald-james-oliver-goldsborough/1117766915?ean=9781935212324&itm=1&usri=9781935212324&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (26, 9, "Ebay", "http://product.half.ebay.com/The-Paris-Herald-by-James-Oliver-Goldsborough-2014-Hardcover/177570779&cpid=5000066609777");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (27, 10, "Amazon", "http://www.amazon.com/gp/product/1477820272/ref=x_gr_w_bb?ie=UTF8&tag=httpwwwgoodco-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=1477820272&SubscriptionId=1MGPYB6YW3HWK55XCGG2");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (28, 10, "Barnes&Noble", "http://www.barnesandnoble.com/w/the-glassblower-samuel-willcocks/1120060885?ean=9781477820278&itm=1&usri=9781477820278&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (29, 10, "Ebay", "http://product.half.ebay.com/The-Glassblower-1-by-Petra-Durst-Benning-2014-Paperback/202788877&cpid=5000081898429");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (30, 11, "Amazon", "http://www.amazon.com/gp/product/1933515759/ref=x_gr_w_bb?ie=UTF8&tag=httpwwwgoodco-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=1933515759&SubscriptionId=1MGPYB6YW3HWK55XCGG2");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (31, 11, "Barnes&Noble", "http://www.barnesandnoble.com/w/fallen-mark-terry/1100240749?ean=9781933515755&itm=1&usri=9781933515755&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (32, 11, "Ebay", "http://product.half.ebay.com/The-Fallen-1-by-Mark-Terry-2010-Hardcover/79636964&cpid=1399436872");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (33, 12, "Amazon", "http://www.amazon.com/gp/product/0399172920/ref=x_gr_w_bb?ie=UTF8&tag=httpwwwgoodco-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=0399172920&SubscriptionId=1MGPYB6YW3HWK55XCGG2");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (34, 12, "Barnes&Noble", "http://www.barnesandnoble.com/w/havana-storm-clive-cussler/1118902945?ean=9780399172922&itm=1&usri=9780399172922&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (35, 12, "Ebay", "http://product.half.ebay.com/Havana-Storm-23-by-Dirk-Cussler-and-Clive-Cussler-2014-Hardcover/201715248&cpid=5000073940658");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (36, 13, "Amazon", "http://www.amazon.com/gp/product/0307719219/ref=x_gr_w_bb?ie=UTF8&tag=httpwwwgoodco-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=0307719219&SubscriptionId=1MGPYB6YW3HWK55XCGG2");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (37, 13, "Barnes&Noble", "http://www.barnesandnoble.com/w/why-nations-fail-daron-acemoglu/1110776486?ean=9780307719218&itm=1&usri=9780307719218&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (38, 13, "Ebay", "http://product.half.ebay.com/Why-Nations-Fail-The-Origins-of-Power-Prosperity-and-Poverty-by-James-Robinson-and-Daron-Acemoglu-2012-Hardcover/109035956&cpid=5000000230332");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (39, 14, "Amazon", "http://www.amazon.com/gp/product/0465081452/ref=x_gr_w_bb?ie=UTF8&tag=httpwwwgoodco-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=0465081452&SubscriptionId=1MGPYB6YW3HWK55XCGG2");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (40, 14, "Barnes&Noble", "http://www.barnesandnoble.com/w/basic-economics-thomas-sowell/1102238333?ean=9780465081455&itm=1&usri=9780465081455&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (41, 14, "Ebay", "http://product.half.ebay.com/Basic-Economics-A-Citizens-Guide-to-the-Economy-by-Thomas-Sowell-2003-Hardcover-Revised-Expanded/4448309&cpid=1186147033");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (42, 15, "Amazon", "http://www.amazon.com/Chinas-Super-Consumers-Billion-Customers/dp/1118834747/ref=sr_1_1?s=books&ie=UTF8&qid=1418149918&sr=1-1&keywords=China%27s+Super+Consumers%3A+What+1+Billion+Customers+Want+and+How+to+Sell+it+to+Them&pebp=1418149920668");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (43, 15, "Ebay", "http://product.half.ebay.com/Chinas-Super-Consumers-What-1-Billion-Customers-Want-and-How-to-Sell-It-to-Them-by-Michael-Zakkour-and-Savio-Chan-2014-E-book/201562681&cpid=5000079801623");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (44, 15, "Google Play", "https://play.google.com/store/search?q=9781118834824&c=books&PAffiliateID=10lHMS");

INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (45, 16, "Amazon", "http://www.amazon.com/Econometrics-Dummies-Roberto-Pedace/dp/1118533844/ref=sr_1_1?s=books&ie=UTF8&qid=1418150076&sr=1-1&keywords=Econometrics+For+Dummies&pebp=1418150078242");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (46, 16, "Barnes&Noble", "http://www.barnesandnoble.com/w/econometrics-for-dummies-roberto-pedace/1114018194?ean=9781118533871&itm=1&usri=9781118533871&cm_mmc=AFFILIATES-_-Linkshare-_-GwEz7vxblVU-_-10:1&r=1,%201");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (47, 16, "Ebay", "http://product.half.ebay.com/Econometrics-for-Dummies-by-Roberto-Pedace-2013-E-book/159970001&cpid=5000052408892");
/*
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (48, 17, "Amazon", "http://www.amazon.com/gp/product/1906964440/ref=x_gr_w_bb?ie=UTF8&tag=httpwwwgoodco-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=1906964440&SubscriptionId=1MGPYB6YW3HWK55XCGG2");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (49, 17, "Barnes&Noble", "http://www.barnesandnoble.com/noresults?store=book&pt=bk&ern=210&isbn=1906964440&r=1,%201&cm_mmc=affiliates-_-linkshare-_-gwez7vxblvu-_-10:1");
INSERT INTO book_seller (ID, bookID, seller_name, seller_url) VALUES (50, 17, "Ebay","http://search.half.ebay.com/1906964440_W0QQmZbooksQQtgZproducts");

*/

INSERT INTO doc (docID, url, type) VALUES (1, "http://cdn.oreilly.com/oreilly/booksamplers/9781449390549_sampler.pdf", 'doc');
INSERT INTO doc (docID, url, type) VALUES (2, "http://cdn.oreillystatic.com/oreilly/booksamplers/9781449340131_sampler.pdf", 'doc');
INSERT INTO doc (docID, url, type) VALUES (3, "https://www.youtube.com/watch?v=upheWDsEAzM", 'video');
INSERT INTO doc (docID, url, type) VALUES (5, "https://www.youtube.com/watch?v=kOSA8w7F730", "video");
-- INSERT INTO doc (docID, url, type) VALUES (6, "http://theoneandonlyivan.com/", "video");
INSERT INTO doc (docID, url, type) VALUES (8, "https://www.youtube.com/watch?v=aIYRi9FrI04", 'video');
INSERT INTO doc (docID, url, type) VALUES (9, "http://www.markterrybooks.com/fallen-chapters-1-6.pdf", "doc");
INSERT INTO doc (docID, url, type) VALUES (11, "https://www.youtube.com/watch?v=YkoMNcYGmtQ", "video");
INSERT INTO doc (docID, url, type) VALUES (12, "http://www.lse.ac.uk/assets/richmedia/channels/publiclecturesandevents/slides/20110608_1830_whynationsfail_sl.pdf", "doc");
INSERT INTO doc (docID, url, type) VALUES (13, "https://www.youtube.com/watch?v=IRAkz13cpsk", "video");
INSERT INTO doc (docID, url, type) VALUES (14, "https://www.youtube.com/watch?v=vEP4RIOKuE4", "video");
INSERT INTO doc (docID, url, type) VALUES (16, "http://thirdparadigm.org/doc/45060880-When-Money-Dies.pdf", "doc");




INSERT INTO book_doc ( bookID, docID ) VALUES (1, 1);
INSERT INTO book_doc ( bookID, docID ) VALUES (2, 2);
INSERT INTO book_doc ( bookID, docID ) VALUES (2, 3);

INSERT INTO book_doc ( bookID, docID ) VALUES (6, 5);
INSERT INTO book_doc ( bookID, docID ) VALUES (7, 6);
INSERT INTO book_doc ( bookID, docID ) VALUES (9, 8);
INSERT INTO book_doc ( bookID, docID ) VALUES (11, 9);
INSERT INTO book_doc ( bookID, docID ) VALUES (12, 11);
INSERT INTO book_doc ( bookID, docID ) VALUES (13, 12);
INSERT INTO book_doc ( bookID, docID ) VALUES (13, 13);
INSERT INTO book_doc ( bookID, docID ) VALUES (16, 14);
INSERT INTO book_doc ( bookID, docID ) VALUES (16, 16);





INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (1, "Linda", "zhuyan@umd.edu", "Linda", 1, "I am an admin of this website. Welcome any suggestion.", 5);

INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (2, "Yan", "mail2yanzhu@gmail.com", "Yan", 0, "This is Yan. I love learning python.", 6);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (3, "Mike", "mike@gmail.com", "Mike", 0, "intro", 7);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (4, "John", "john@gmail.com", "John", 0, "intro", 8);

INSERT INTO user (userID, user_name, email, user_password, user_type)
VALUES (5, "David", "david@gmail.com", "David", 0);

INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (6, "Yuqing", "1205369103@qq.com", "Yuqing", 1, "admin", 5);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (7, "Krith", "Krith@gmail.com", "Krith", 0, "intro", 6);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (8, "James", "James@gmail.com", "James", 0, "intro", 6);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (9, "Adel", "adel@gmail.com", "Adel", 0, 'intro', 7);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (10, "Sam", "sam@gmail.com", "sam", 0, "intro", 7);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (11, "Adam", "adam@gmail.com", "adam", 0, "intro", 7);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (12, "Justin", "justin@gmail.com", "justin", 0, "intro", 7);
INSERT INTO user (userID, user_name, email, user_password, user_type, introduction, imageID)
VALUES (13, "Ross", "ross@gmail.com", "ross", 0, "intro", 5);





INSERT INTO user_book (userID, bookID) VALUES (2, 1);
INSERT INTO user_book (userID, bookID) VALUES (2, 2);




INSERT INTO user_user (userID1, userID2) VALUES (2, 3) ;


INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text, points)
VALUES (1, 2, '2014-10-29', 5, "I love this book!", 
	"It is written in such a manner that I retain what I read, as if it is written just for me. You can't ask for more than that from an author. Their way of going about teaching you is, in my opinion, the greatest thing since sliced bread. It is written in a conversational style, with graphics which evoke emotions.", 
	1); 
INSERT INTO comment (bookID, userID, comment_date, score,comment_title, comment_text)
VALUES (1, 3, '2014-10-29', 5, "It's a great book", "very useful and easy to understand.");

INSERT INTO comment (bookID, userID, comment_date, score, comment_text)
VALUES (1, 5, '2014-10-30', 4, "The graphs help you to retain what you read, because as the authors say, 'A picture is worth a thousand words.'") ;

INSERT INTO comment (bookID, userID, comment_date, score, comment_text) 
VALUES (1, 4, '2014-10-30', 4, "The graphs help you to retain what you read, because as the authors say, 'A picture is worth a thousand words.'"); 

INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 3, '2013-09-23', 5, "Good Introduction", "Econometrics is an area of statistics that deals with building models from data. This book offers a good introduction to econometrics and covers all the basic concepts from ordinary least square, hypothesis testing, Guass-Markov, heteroscedasticity, covariance, correlation and modeling strategies. The content is inevitably mathematical in nature, so some familiarity with mathematical notation for arithmetic sums and basic calculus is assumed. If you are doing a survey course, this provides a clear exposition in a fairly traditional textbook format. If you like to learn by doing problems I think Schaum's Outline of Statistics and Econometrics, Second Edition (Schaum's Outline Series) is another good and affordable choice. You could also check out Ben Lambert's introductory course to econometrics on youtube. The author provides examples that use the SATA statistical software package for some examples. This does not limit the value of the content, but it would have been nice if the data sets were downloadable from the book's website.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 4, '2014-01-22', 5, "Great for Econometrics course", "For my masters level finance course we had DeFusco's CFA Quant book, and I also bought the Schweser study material. The DeFusco book was a pain, and the Schweser material didn't go far enough. This book made it so I could catch up and then excel in the class (of course when it was almost over). Great STATA examples, very easy to understand and logical layout. It walks you through econometrics from the basics into more advanced topics with ease, makes other books easy to understand. This book has probably the greatest cost/benefit ratio of any book I've purchased. Highly Recommend.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 5, '2014-02-15', 4, "For Dummies?", "I’m an MBA and MS in Management Information Systems student who took my required statistics class with an economics professor and became interested in econometrics. I found that this book gave me an excellent understanding of the subject in a way that I found easy to understand. However, I do have a background in economics and statistics (from my undergraduate business degree and graduate studies) that was at times important for my understanding of the topics covered in this book. I would highly recommend this book to someone with background knowledge of statistics and economics and an interest in econometrics, but I wouldn’t say that it’s a good book for someone without that sort of a background.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 6, '2014-04-09', 4, "For the college student", "This is a book meant to be read after you've taken some Economics classes already. You could read it either as a supplement to your class text books or - probably better and less confusing, read it in the break between semesters. The author assumes you are in college, possibly even a graduate student, and that you're a whiz at algebra, statistics and more. They will slap a 'for Dummies' label on anything these days, it seems." );
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 7, '2014-06-24', 3, "Lacking detailed explanations", "Too many references to other 'Dummies' books for full explanations of problem solutions. I have a feeling the other books likely do the same in order to sell the purchaser as much as possible.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 8, '2014-07-21', 4, "NOT For Someone Who Knows NOTHING About The Subject!", "The author assumes you already know algebra, principles of economics, and statistics. He assumes you already know numbers, equations, and Greek letters. He aso assumes you will be using econometrics software and can adapt his examples to software other than STATA if that's not what you are using.");

INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 9, '2014-08-05', 4, "A decent introduction", "
Don't let the title fool you: this isn't a run of the mill Dummies book. Like Economics for Dummies Econometrics largely lacks the wittiness and humor of the typical Dummies title.
That being said, you get what you pay for. Roberto Pedace offers an introductory overview of the field and its principles, and he assumes less about the reader's foreknowledge than a standard academic work might. The largest issue is the book's almost total reliance on STATA in the early chapters. At times, the book feels less like an introduction to the field as a whole than it is a software manual for STATA. Also, while Pedace's hands-on approach is very much in the Dummies series vein and highly useful, a bit more discussion on the concepts being used would have been welcome.");

INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 10, '2014-08-21', 5, "Godsend!", "I had the world's worst teacher for a Master's level Econometrics class. His syllabus literally read this is a math based class so I can't teach it to you. This book saved me! It explains things very well and provides examples that anyone can understand. Definitely go for it if you're struggling.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 11, '2014-09-27', 5, "Econometrics made easy!", "Good book to learn more about econometrics. I used it as a supplemental book for my econometrics course in college and it helped a lot.");

INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (16, 12, '2013-08-25', 4, "Kind of an odd duck for the Dummies series, but decent text", 
	"I'm writing this review as a research professional with a graduate degree in econ. I took enough econometrics that I'm familiar with most of the topics in this text. I'm approaching this review from the standpoint of how well this text fits in the Dummies series, and I don't think it does. This isn't a text that will take a person unfamiliar with stats or econ and give them a functional understanding of econometrics."); 

INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (3, 2, '2014-10-07', 5, "Rain Reign was amazing, powerful","To tell you guys the truth, when I was contacted to review Rain Reign I didn't quite know what to expect, especially because it's described as a powerful story and brilliantly told. I mean, I devoured all of Ms. Martin's Babysitter's Club books I could get my hands on when I was in the fourth and fifth grade, but it's been years and years since I read a book by her. I can name all of the BSC members but I wouldn't call the books in the series powerful. The BSC books were fun but, you know, ultimately forgettable.");

INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (3, 5, '2014-11-09', 4, "Rose is a hero who's only weapon is her heart.", "Rose Howard is a twelve-year-old girl who is in fifth grade. She is a highly functioning autistic obsessed with homonyms, rules, and prime numbers. She lives in a small town with her father, who spends more time at the local bar than home with Rose, and her dog Rain Reign (homonym!). All Rose knows of her mother is a box of trinkets she occasionally goes through when she has nothing else to do. Rose and Rain have a pretty good life, except for when Rose loses control of herself and gets in trouble at school or tests her father's patience too much. They stick to their schedule, keeping order in Rose's world, and have the good fortune to have Uncle Weldon in their lives. When Hurricane Susan hits, Rose is worried about the storm and all the talking on television, but after the storm she has much more to worry about. ");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (4, 9, '2014-10-08', 4, "Remix of fairy tales", "This book remixes fairy tales. It's a world where princesses and knights fight witches and dragons. It's a world with dozens of small kingdoms, giants, and dark, magical forests. And from this world comes an unnamed girl, wearing spider silk, on her way to join Pennyroyal Academy.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (5, 7, '2014-09-14', 5, "in awe of this great book!", "I saw this book at our library on the 'new books' shelf and grabbed it for my 5-year-old train-loving son. I just finished reading it to him... I didn't time it, but it took over 20 minutes to read, I am sure. maybe a full half hour? the time went by fast for us, though. we both really loved it. and my 3 year old and 8 year old daughters listened to the majority of it as well. What can I say that hasn't been said in the previous thorough review... I don't have much to add, since I agree with everything in that review. The pictures were amazing. Very simple, yet at the same time, detailed. I can't explain it! Just right to hold the attention of my three kids through all of the text. And the text itself was also captivating. There was a rhythm to it, but it wasn't at all sing song-y. I don't particularly care for the sing song-y rhyming books. I loved the cadence of this book... it was just the right rhythm to correspond to the rolling rumbling train. The imagery was so wonderful and you really felt like you were there on the long trip. The fact that this book held the attention of my kids despite its length says it all. I do plan to purchase this book... but I wanted to throw my review in the pot immediately! so glad I stumbled on this book!!");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (5, 10, '2014-10-22', 5, "What a beautiful story", "Mr Brian Floca has done a wonderful job with this book. The story is so well written and the illustrations are beautiful, simply beautiful. What a great way to spend a night riding the rails. He makes you feel like you are right there in the story. This is already going to be a new favorite at my house. I had the pleasure of meeting Mr. Floca at my local independent bookstore, for an author event, and I was in awe of his great work. His presentation on how he developed the book was phenomenal. He researched and experienced the locomotive, and you can tell his heart is in this book by the way the story just flows on the pages.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (5, 2, '2014-11-23', 5, "Beautiful train book", "I bought this book for my grandson who loves trains. While I didn't read it, my husband, a retired railroader, did and pronounced the book a beautiful book. He and our grandson share their love of trains. The pictures are lovely and the text is well written according to my husband.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (5, 6, '2014-12-01', 5, "Two year old loves pictures!", "I bought this book for my two year old. He loves the pictures. As he gets older we will be able to read the story to him. Great book.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (6, 4, '2014-04-14', 5, "Delightful and Different", "This is such a lovely, creative book! My son and daughter (3 1/2 year old twins) both love this book. It's an active book for them as they keep jumping off my lap to copy Flora's moves in their own little dance. Though a book without words was something new for them at first, they see something new in the pages every time we read it.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (6, 6, '2014-07-28', 5, "Wordless, but full of wonder", "This delightful book comes without any words, but contains plenty of story just waiting for a child to discover it. Flora does her best to imitate a flamingo, both in her attire and her actions. The flamingo, noticing her and apparently disapproving, contorts into increasingly difficult poses until Flora topples. Then, noting her distress and feeling apologetic, the flamingo enters into a duet with Flora to finish out the book.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (6, 8, '2014-10-18', 4, "Picture book without text with which the author still manages to say a lot", "The story is illustrated using simple, but elegant and precisely drawn figures of two dancers, while all the background, except pink tree with blossoms, is painted in white not to distract the reader.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (7, 10, '2014-04-08', 5, "Wonderful", "I was hesitant to chose this book thinking an animal book would be too silly or something . . . but Applegate's Home of the Brave is one of my favorite books ever so I decided to take a chance. And I am SO GLAD I DID. This book was wonderful--heartbreakingly wonderful. I just loved every character--both animal and human. Ivan the artistic gorilla, Stella the stoic mother elephant, Bob the tough on the outside but not so tough on the inside dog, and of course Ruby the baby elephant who just wants to be loved. And the humans: George the sympathetic caretaker and his daughter Julie, a bit like Fern in Charlotte's web because she can almost understand Ivan--or at least understand his art. Every character was real--even Mack the owner of the menagerie, though we hate what he's doing, there is more too him than just badness. The situation was just so sad but so well done--the minute I finished the book, I immediately passed it on to my daughter . . . maybe not the best idea to give it to her at bedtime though because I could not get her to turn out her light, she was so immediately drawn into the book. I highly recommend this moving book which teaches compassion towards animals.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (9, 2, '2014-04-08', 5, "Another moveable feast", "Goldsborough captures the rhythms of a great newspaper trying to survive amid the turmoil of political, labor and capitalist pressures that intersected with Charles de Gaulle's final years. The author deftly fuses fact and fiction to make this a compelling read, particularly for anyone who relishes a time when newspapers and the journalists who produced them really mattered. And for anyone who has been to Paris and longs to return to that magical city.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (9, 13, '2014-07-24', 4, "Another Moveable Feast ?", "I picked The Paris Herald up at B&N for the cover, knowing nothing of the story but loving the photo. What an amazing story, one I'd never heard before. Why did it take so long for someone to write about it.? As for it being the best story of Americans in Paris since Hemingway's Moveable Feast -- why not? It is exactly the same kind of story told a century later. Doesn't sound like that much has changed either.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (9, 11, '2014-09-13', 5, "Thoroughly Engaging!", "This Updike-like novel presents a look at the 1960's in Paris and reflects a decade of change in Europe and the beginnings of change in the world of journalism from the points of views of Americans who remain essentially outsiders in the culture in which they live and work.The tone is one of detached irony; the characters are engaged in primarily superficial relationships which was an aspect of the new morality; and the setting reveals the importance of place in fiction. One fascinating bit is the pressure that De Gaulle and his advisers put on the Herald to stay in Paris which was also supported by Katharine Graham of the Washington Post who was willing to accept a minority interest and to put money into the Herald to keep it alive.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (10, 6, '2014-09-13', 5, "Shockingly Realistic, a Great Read", "The Glassblower is not the type of book I usually read. I selected it from Kindle First because the premise of the story was interesting, but I really did not expect to be drawn into the book ad I was. I could not put it down. The descriptions of life in 1800s Germany and of young women trying to make a place for themselves in a profession dominated by men were so realistic I was able to form a mental image of the village, the characters. I hope to read other nooks by this author and will definitely recommend it.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (10, 9, '2014-11-16', 5, "Utterly gorgeous novel!", "I cannot tell you how much I enjoyed this novel! It is beautifully written and each of the characters are so wonderfully developed. I received this book through Amazon's Kindle First book of the month. The books I have gotten through this program in the past have been sort of hit and miss, but this one was a real treat. This book reminded me of one of my all-time favorite novels, Fall on Your Knees by Ann-Marie MacDonald, in that it is another historical fiction novel that centers primary on three very close, yet very different, sisters. Originally published in German several years ago, this novel is part of a trilogy that is in the process of being translated to the English language for the first time. This first offering in the series will be making making its English debut on November 1, 2014.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (10, 11, '2014-11-28', 2, "warning: this book includes descriptions of rape and violence against women", "I don't know if this is a cultural difference (this book was written in German and translated into English) but I do not expect to encounter graphic descriptions of wife beating and rape in historical fiction. There is also WAY more sex in this book than I would have expected-- of the bodice-ripper, romance novel type. But it's the rape and beating that I note for other readers-- if you, like me, find such descriptions gratuitous and disturbing, avoid this book. The plot and story in general are interesting, thus the two stars, but the writing is wooden. Don't know if that is the translation or the original text, but unless you have a deep interest in artisanship/ art (which I do) you really don't need to read this book, in my opinion.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (11, 8, '2010-03-08', 5, "Move over Seagal, Stillwater has arrived", "The Fallen by Mark Terry is a very well done, albeit formulaic novel. The hero, Derek Stillwater, is your classic hero with a mysterious past about which few facts can be confirmed. Terry uses the familiar G8 summit as his backdrop and creates a sense of realism that few authors can match. Protests occur at nearly every international meeting of world leaders and the G8 summit is no exception. I think it is just a matter of time before something similar to the events in Terry's novel happens in real life. Of course, in the novel, the mysterious hero is already in place to beat the odds, save the girl and prevent disaster. Terry does a great job of creating a scenario that while very formulaic is still very interesting and engaging to read. I completed the novel nearly in one sitting and I predict many who pick up this book will do the same. I heartily give this book 5 of 5 stars.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (12, 4, '2011-05-18', 3, "There are better Cussler books out there", "Set in 2016, following the death of Fidel Castro, the story is about the search for two halves of an Aztec artifact. The links to the sinking of the Maine and background on the Spanish-American War are not really necessary and could have tightened up this 450 page novel. Having just read Cussler’s very exciting Ghost Ship and Zero Hour. I found this to be very average. I usually enjoy Cussler’s undersea adventures, but there was too much detail about equipment and armaments. Since I do not read all of Cussler’s series, I finished this book thinking that Cussler’s co-authors have different levels of writing talent.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (12, 5, '2012-07-19', 4, "ACTION AND ADVENTURE ABOUND!", "Just the name Cussler on the cover lets us know that action abounds beginning with the first page or in this case first few words. And, speaking of which those words are spoken by the estimable Scott Brick, an actor/writer who has umpteen film stage, television and radio appearances to his credit. That experience is evident as he delivers a gripping narration of this adventure thriller again featuring the intelligent, charismatic do-gooder Dirk Pitt, chief of the National Underwater Marine Agency.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (13, 8, '2012-09-14', 5, "A Return To Political Economy", "Why are some nations rich and others poor? The question has occupied economists since Adam Smith wrote An Inquiry into the Nature and Causes of the Wealth of Nations. As Nobel laureate Robert Lucas said, once you start thinking about that question, it is hard to think about anything else. Daron Acemoglu and James Robinson have been thinking hard about it, and Why Nations Fail provides their answer.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (13, 9, '2013-11-14', 3, "3.0 out of 5 stars Erudite, ever so meandering, and ultimately inconclusive", "I find the topic utterly fascinating: why do some nations prosper, and improve the life of their citizens, and others fail, often disastrously so? Daron Acemoglu and James Robinson, both academics, propose a model based on the concepts of extractive vs. inclusive institutions. They attempt to support their thesis by undertaking a very broad review of economic and historical developments in a spectrum of 30 or so countries. They commence, like medical researchers do when they hope to minimize the number of variables, by examining twins. In the author's case the are the cities of Nogales, immediately adjacent, in Arizona, and in Sonora. One is relatively prosperous, the other not so. It is a good start, and later in the book, the author uses the two Koreas. In both cases, geography and culture are relatively constant, which seems to bolster their view that it is the institutions that govern the lives of the respective citizens that are causative.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (13, 11, '2014-03-12', 2, "LOOSE ELASTIC", "The problem is that the authors purport to be experts on everything and on every age, when in fact they are masters of nothing but a theory; and the theory is so broad and vague as to be almost incapable of proof or disproof. Thus centralisation + inclusive institutions = lasting economic success and prosperity. I think I go along with this to some extent; but the terms are very elastic. What degree of centralisation counts as such? What is meant by `inclusive' or for that matter `extractive'? They may be right about the USSR and China; but I am not sure they have explained why the former failed and why the seemingly inexorable rise of the latter may be an illusion.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (14, 12, '2011-02-05', 5, "Blows Away Any Other Book You Will Read On Economics", "There's a story Milton Friedman use to tell when he was the Nobel Prize winning Professor of Economics at the University of Chicago. He would say that an economist is a man that knows a thousand ways to make love, but has never been with a woman. The truth of this statement is embodied in just about every concept you will study in economics, and the people responsible for those concepts. It is as though they go out of their way to be as confusing as possible. They use language that only a fellow economist could hope to understand but probably doesn't.");
INSERT INTO comment (bookID, userID, comment_date, score, comment_title, comment_text)
VALUES (15, 13, '2014-10-22', 5, "Don't leave the house for China without this book", "By way of background, I completed my first consulting engagement in China in 1997 and having lived and worked in Shanghai for the past two years. China's Super Consumers (Part I) has put what I've been observing for the past 15 years in a historical context. Part II's first three chapters precisely define China's 'Super Consumers,' with whom I often travel the New York-Shanghai route. I especially appreciated the tactically-oriented chapters, including on marketing--for example, the importance of peer recommendations and promoting cultural values and individual aspirations ('The Chinese Dream'). For anyone who intends to do business in China or with Chinese consumers, reading and absorbing this book should be your first stop. As Savio and Michael point out, immerse yourself, be patient, and remember it's a long-term game.");



INSERT INTO helpful (commentID, userID) VALUES (1, 4) ;

