__author__ = 'Yan'

import sqlite3
from flask import Flask, request, session, g, redirect, url_for, \
     abort, render_template, flash, jsonify
from contextlib import closing
from datetime import date
import random
from flask.ext.mail import Mail, Message

# import os
# from werkzeug import secure_filename
# import smtplib
# UPLOAD_FOLDER = '/static/image/user'
# ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])



# configuration
# DATABASE = 'IBDB.db' # OperationalError: unable to open database file
DATABASE = 'C:\\Users\\Yan\\OneDrive\\INFM743 python\\INFM743_project_MasalaTofu\\IBDB.db'
DEBUG = True
SECRET_KEY = 'development key'



app = Flask(__name__)
app.config.from_object(__name__)
# app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config.update(
    DEBUG=True,
    #EMAIL SETTINGS
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=587,
    #MAIL_USE_SSL=True,
    MAIL_USE_TLS = True,
    MAIL_USE_SSL = False,
    MAIL_USERNAME = 'internetbookreviewdatabase',
    MAIL_PASSWORD = 'infm743@123',
    MAIL_DEBUG = True
    )
mail=Mail(app)


def connect_db():
    print app.config['DATABASE']
    return sqlite3.connect(app.config['DATABASE'])


@app.before_request
def before_request():
    g.db = connect_db()

@app.teardown_request
def teardown_request(exception):
    db = getattr(g, 'db', None)
    if db is not None:
        db.close()


def init_db():
    with closing(connect_db()) as db:
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()



class Database():
    """docstring for ClassName"""
    # def __init__(self, arg):
    #     super(ClassName, self).__init__()
    #     self.arg = arg

    # get all

    def getAllAuthors(self):
        cur = g.db.execute('select * from author')
        authors = [dict(id=row[0], name=row[1]) for row in cur.fetchall()]
        return authors

    def getAllPublishers(self):
        cur = g.db.execute('select * from publisher')
        publishers = [dict(id=row[0], name=row[1]) for row in cur.fetchall()]
        return publishers

    def getAllCategories(self):
        cur = g.db.execute('select * from category')
        categories = [dict(id=row[0], name=row[1]) for row in cur.fetchall()]
        return categories


    # search or show a list of book

    def searchBooksAdv(self, args):
        pass

    def searchAutBooks(self, searchInput):
        cur = g.db.execute("SELECT b.bookID, b.title, i.url, c.name, GROUP_CONCAT(a.name) \
            FROM book b, book_image bi, image i, category c, book_author ba, author a \
            WHERE b.bookID=bi.bookID and bi.imageID=i.imageID and bi.cover=1 and b.categoryID=c.categoryID \
            and ba.bookID=b.bookID and ba.authorID=a.authorID \
            and lower(a.name) LIKE '%'||?||'%' \
            GROUP BY b.bookID, b.title ", [searchInput])
        books = [dict(bookID=row[0], title=row[1], cover=row[2], category=row[3], authors=row[4]) for row in cur.fetchall()]
        return books

    def searchTitleBooks(self, searchInput):
        cur = g.db.execute("SELECT b.bookID, b.title, i.url, c.name, GROUP_CONCAT(a.name) \
            FROM book b, book_image bi, image i, category c, book_author ba, author a \
            WHERE b.bookID=bi.bookID and bi.imageID=i.imageID and bi.cover=1 and b.categoryID=c.categoryID \
            and ba.bookID=b.bookID and ba.authorID=a.authorID \
            and lower(b.title) like '%'||?||'%' \
            GROUP BY b.bookID, b.title ", [searchInput])
        books = [dict(bookID=row[0], title=row[1], cover=row[2], category=row[3], authors=row[4]) for row in cur.fetchall()]
        return books

    def getCatBooks(self, categoryID):
        cur = g.db.execute("SELECT b.bookID, b.title, i.url, c.name, GROUP_CONCAT(a.name) \
            FROM book b, book_image bi, image i, category c, book_author ba, author a \
            WHERE b.bookID=bi.bookID and bi.imageID=i.imageID and bi.cover=1 and b.categoryID=c.categoryID \
            and ba.bookID=b.bookID and ba.authorID=a.authorID \
            and c.categoryID = ? \
            GROUP BY b.bookID, b.title ", [categoryID])
        books = [dict(bookID=row[0], title=row[1], cover=row[2], category=row[3], authors=row[4]) for row in cur.fetchall()]
        return books


    # one book's info

    def getABook(self, bookID):
        cur = g.db.execute("SELECT b.bookID, b.title, ISBN13, pub_year, pages, introduction, contents, \
            i.url, c.name, p.name, p.city, p.country \
            FROM book b, book_image bi, image i, category c, publisher p \
            WHERE b.bookID=bi.bookID and bi.imageID=i.imageID and bi.cover=1 and b.categoryID=c.categoryID \
            and  b.publisherID=p.publisherID \
            and b.bookID = ? ", [bookID])
        book = [dict(bookID=row[0], title=row[1], ISBN13=row[2], year=row[3], pages=row[4], introduction=row[5], contents=row[6],
            cover=row[7], category=row[8], publisher=row[9]+', '+row[10]+', '+row[11] ) for row in cur.fetchall()]
        return book

    def getAuthors(self, bookID):
        cur = g.db.execute("SELECT bookID, a.authorID, a.name FROM book_author ba, author a \
            WHERE ba.authorID=a.authorID and bookID = ? ", [bookID])
        authors = [dict(authorID=row[1], name=row[2]) for row in cur.fetchall()]
        return authors

    def getSellers(self, bookID):
        cur = g.db.execute("SELECT * FROM book_seller WHERE bookID = ? ", [bookID])
        sellers = [dict(name=row[2], url=row[3]) for row in cur.fetchall()]
        return sellers

    def getImages(self, bookID): # non-cover images
        cur = g.db.execute("SELECT i.imageID, url FROM book_image bi, image i \
            WHERE bi.imageID=i.imageID and bi.cover=0 and type='book' \
            and bookID = ? ", [bookID])
        images = [row[1] for row in cur.fetchall()]
        return images

    def getSamples(self, bookID):
        cur = g.db.execute("SELECT doc.docID, url FROM book_doc bd, doc \
            WHERE bd.docID=doc.docID and type='doc' \
            and bookID = ? ", [bookID])
        docs = [row[1] for row in cur.fetchall()]
        return docs

    def getVideos(self, bookID):
        cur = g.db.execute("SELECT doc.docID, url FROM book_doc bd, doc \
            WHERE bd.docID=doc.docID and type='video' \
            and bookID = ? ", [bookID])
        videos = [row[1].replace('watch?v=', 'embed/') for row in cur.fetchall()]
        return videos


    # ratings
    def getRatingSummary(self, bookID):
        cur = g.db.execute("SELECT avg(score), count(commentID) FROM comment WHERE bookID=?", [bookID])
        ratingSummary = [dict(score=row[0], count=row[1]) for row in cur.fetchall()]
        return ratingSummary

    def getRatingGroups(self, bookID):
        cur = g.db.execute("SELECT score, count(commentID) FROM comment WHERE bookID=? GROUP BY score", [bookID])
        rGroups = [dict(score=row[0], count=row[1]) for row in cur.fetchall()]
        print rGroups
        ratingGroups = {'5': 0, '4': 0, '3': 0, '2': 0, '1': 0 }
        for x in rGroups:
            if x['score'] == 5: ratingGroups['5']=x['count']
            elif x['score'] == 4: ratingGroups['4']=x['count']
            elif x['score'] == 3: ratingGroups['3']=x['count']
            elif x['score'] == 2: ratingGroups['2']=x['count']
            elif x['score'] == 1: ratingGroups['1']=x['count']
            else: print x['score']
        print ratingGroups

        return ratingGroups


    # comments that only have text or title
    def getComments(self, bookID, sort):
        cur = g.db.execute("SELECT commentID, u.userID, u.user_name, comment_date, score, comment_title, comment_text, points \
            FROM comment c, user u \
            WHERE c.userID=u.userID and bookID=? \
            and (comment_text is not null or comment_title is not null) \
            ORDER BY "+sort+", commentID DESC", [bookID])
        comments = [dict(commentID=row[0], userID=row[1], userName=row[2], date=row[3], score=row[4], commentTitle=row[5], commentText=row[6], points=row[7]) for row in cur.fetchall()]
        return comments


    # one author
    def getAnAuthor(self, authorID):
        cur=g.db.execute("SELECT authorID, name, a.url, introduction, i.url FROM author a, image i \
            WHERE a.imageID=i.imageID and type='author' \
            and authorID=?", [authorID])
        author = [dict(authorID=row[0],name=row[1],url=row[2],introduction=row[3],image=row[4]) for row in cur.fetchall()]
        return author

    def getAutBooks(self, authorID):
        cur = g.db.execute("SELECT b.bookID, b.title, i.url, c.name, GROUP_CONCAT(a.name) \
            FROM book b, book_image bi, image i, category c, book_author ba, author a \
            WHERE b.bookID=bi.bookID and bi.imageID=i.imageID and bi.cover=1 and b.categoryID=c.categoryID \
            and ba.bookID=b.bookID and ba.authorID=a.authorID \
            and ba.authorID = ? \
            GROUP BY b.bookID, b.title ", [authorID])
        books = [dict(bookID=row[0], title=row[1], cover=row[2], category=row[3], authors=row[4]) for row in cur.fetchall()]
        return books

    # one user
    def getAUser(self, userID):
        print "userID in class: ", userID
        cur=g.db.execute("SELECT userID, user_name, email, user_password, user_type, introduction, i.url \
            FROM user u LEFT OUTER JOIN image i ON u.imageID=i.imageID \
            WHERE userID=?", [userID])
        user = [dict(userID=row[0],name=row[1],email=row[2],password=row[3],user_type=row[4],introduction=row[5],image=row[6]) for row in cur.fetchall()]
        return user

    def getUserUser(self, myUserID):
        cur=g.db.execute("SELECT userID2, user_name FROM user_user, user WHERE userID2=userID and userID1=?", [myUserID])
        users = [dict(userID=row[0], name=row[1]) for row in cur.fetchall()]
        return users
        
    def getUserBook(self, myUserID):
        cur=g.db.execute("SELECT b.bookID, title FROM user_book ub, book b WHERE ub.bookID=b.bookID and userID=?", [myUserID])
        books = [dict(bookID=row[0], title=row[1]) for row in cur.fetchall()]
        return books

    def getUserComments(self, myUserID):
        cur=g.db.execute("SELECT c.bookID, b.title, score, comment_date, commentID, points FROM comment c, book b \
            WHERE c.bookID=b.bookID and userID=? ORDER BY comment_date DESC", [myUserID])
        comments = [dict(bookID=row[0], booktitle=row[1], score=row[2], date=row[3], commentID=row[4], points=row[5]) for row in cur.fetchall()]
        return comments
        
    
    # one comment
    def getAComment(self, myUserID, bookID):
        cur = g.db.execute("SELECT commentID, u.userID, u.user_name, comment_date, score, comment_title, comment_text, points  \
            FROM comment c, user u WHERE c.userID=u.userID AND c.userID=? AND bookID=?", [myUserID, bookID])
        myComment = [dict(commentID=row[0], userID=row[1], userName=row[2], date=row[3], score=row[4], commentTitle=row[5], commentText=row[6], points=row[7]) for row in cur.fetchall()]
        return myComment



    # add comment, add book
    def add(self, table, columns, values, args):
        g.db.execute("INSERT INTO "+table+" ("+columns+") VALUES ("+values+")", args)
        g.db.commit()

    # add user_book, user_user # see below
    # update (Helpful, MyComment, MyProfile), see below
    # delete (books, users), see below




db=Database()


#******************************************************Added by Krishnesh**********************************

@app.route('/Terms', methods=['GET', 'POST'])
def Terms():
    return render_template('Terms.html')

@app.route('/Privacy', methods=['GET', 'POST'])
def Privacy():
    return render_template('Privacy.html')

@app.route('/Tour', methods=['GET', 'POST'])
def Tour():
    return render_template('Tour.html')

@app.route('/Help', methods=['GET', 'POST'])
def Help():
    return render_template('Help.html')

#**********************************************************************************************************


@app.route('/')
def Home():
    cur = g.db.execute("SELECT b.bookID, b.title, i.url, count(c.commentID)  \
    FROM book_image bi, image i, book b left join comment c ON b.bookID=c.bookID \
    WHERE b.bookID=bi.bookID AND bi.imageID=i.imageID AND bi.cover=1 \
    GROUP BY c.bookID ORDER BY count(c.commentID) DESC LIMIT 4")
    booksHot = [dict(bookID=row[0], title=row[1], cover=row[2], count=row[3]) for row in cur.fetchall()]
    print booksHot

    cur = g.db.execute("SELECT b.bookID, b.title, i.url, b.pub_year FROM book b, book_image bi, image i \
    WHERE b.bookID=bi.bookID AND bi.imageID=i.imageID AND bi.cover=1 \
    ORDER BY b.pub_year DESC LIMIT 4")
    booksNew = [dict(bookID=row[0], title=row[1], cover=row[2], year=row[3]) for row in cur.fetchall()]
    print booksNew

    cur = g.db.execute("SELECT b.bookID, b.title, i.url FROM book b, book_image bi, image i \
    WHERE b.bookID=bi.bookID AND bi.imageID=i.imageID AND bi.cover=1")
    booksAll = [dict(bookID=row[0], title=row[1], cover=row[2]) for row in cur.fetchall()]
    print booksAll
    booksRadom = []
    while len(booksRadom) < 4:
        randindex = random.randint(0, len(booksAll)-1) # get a random int
        randBook = booksAll[randindex]
        booksRadom += [ randBook ]
        del booksAll[randindex]
    print booksRadom
    return render_template('Home.html', booksHot=booksHot, booksNew=booksNew, booksRadom=booksRadom)


@app.route('/homeCat')
def homeCat():
    categoryID = request.args.get('catID')
    print "categoryID=", categoryID
    books = db.getCatBooks(categoryID)
    return render_template('HomeCat.html', books=books)



@app.route('/searchBooks', methods=['GET', 'POST'])
def searchBooks():
    if request.method == 'POST':
        searchInput = request.form['searchInput'].strip().lower()
        searchType = request.form['searchType']
        print "searchInput=", searchInput, "; searchType=", searchType
        if searchType == 'author':
            books = db.searchAutBooks(searchInput)
        else:
            books = db.searchTitleBooks(searchInput)
        count = len(books)
        print count
        return render_template('showBooks.html', books=books, count=count)
    else:
        return render_template('showBooks.html', count=0)


@app.route('/showBooks', methods=['GET', 'POST'])
def showBooks():
    if request.args.get('catID'):
        categoryID = request.args.get('catID')
        print "categoryID=", categoryID
        books = db.getCatBooks(categoryID)
    else:
        authorID = request.args.get('authorID')
        print "authorID", authorID
        books = db.getAutBooks(authorID)
    count = len(books)
    print count
    return render_template('showBooks.html', books=books, count=count)


@app.route('/showBook/<bookID>', methods=['GET', 'POST'])
def showBook(bookID):
    # if request.method == 'POST': bookID = request.form['bookID']
    # else: bookID = request.args.get('bookID')
    book = db.getABook(bookID)
    authors = db.getAuthors(bookID)
    sellers = db.getSellers(bookID)
    images = db.getImages(bookID)
    samples = db.getSamples(bookID)
    videos = db.getVideos(bookID)
    # ratings
    ratingSummary = db.getRatingSummary(bookID)
    ratingGroups = db.getRatingGroups(bookID)
    # comments that only have text or title
    sort = 'comment_date DESC'
    comments = db.getComments(bookID, sort)
    commentsNum = len(comments)
    return render_template('showBook.html', book=book[0], authors=authors, sellers=sellers, images=images, samples=samples, videos=videos,
                           ratingSummary=ratingSummary[0], ratingGroups=ratingGroups, comments=comments, commentsNum=commentsNum)


@app.route('/showComments', methods=['GET', 'POST'])
def showComments():
    bookID = request.args.get('bookID')
    sortValue = request.args.get('sort')
    print bookID, sortValue
    if sortValue == '1':
        sort = 'score DESC'
    elif sortValue == '2':
        sort = 'score'
    elif sortValue == '3':
        sort = 'points DESC'
    elif sortValue == '4':
        sort = 'points'
    elif sortValue == '5':
        sort = 'comment_date'
    else:
        sort = 'comment_date DESC'
    print bookID, sort
    comments = db.getComments(bookID, sort)

    book = db.getABook(bookID)
    ratingSummary = db.getRatingSummary(bookID)
    ratingGroups = db.getRatingGroups(bookID)
    return render_template('showComments.html', book=book[0], comments=comments, sortValue=sortValue, ratingSummary=ratingSummary[0], ratingGroups=ratingGroups)


@app.route('/addBookToList', methods=['GET', 'POST'])
def addBookToList():
    if not session.get('logged_in'):
        return jsonify(result=0)
    else: 
        myUserID = session['userID']
        bookID = request.args.get('bookID')
        # validation (this book is alreday in your list)
        cur = g.db.execute("SELECT count(*) FROM user_book WHERE userID=? AND bookID=?", [myUserID, bookID])
        count = [row[0] for row in cur.fetchall()][0]
        if count == 0:
            g.db.execute("INSERT INTO user_book (userID, bookID) VALUES (?, ?)", [myUserID, bookID])
            g.db.commit()
            return jsonify(result=1)
        else:
            return jsonify(result=2)

@app.route('/addUserToList', methods=['GET', 'POST'])
def addUserToList():
    if not session.get('logged_in'):
        return jsonify(result=0)
    else: 
        myUserID = session['userID']
        userID = request.args.get('userID')
        # validation (this user is already in your list)
        cur = g.db.execute("SELECT count(*) FROM user_user WHERE userID1=? AND userID2=?", [myUserID, userID])
        count = [row[0] for row in cur.fetchall()][0]
        if count == 0:
            g.db.execute("INSERT INTO user_user (userID1, userID2) VALUES (?, ?)", [myUserID, userID])
            g.db.commit()
            return jsonify(result=1)
        else:
            return jsonify(result=2)

@app.route('/updateHelful', methods=['GET', 'POST'])
def updateHelful():
    if not session.get('logged_in'):
        return jsonify(result=0)
    else: 
        myUserID = session['userID']
        commentID = request.args.get('commentID')
        # validation (You've already pressed helpful for this comment)
        cur = g.db.execute("SELECT count(*) FROM helpful WHERE commentID=? AND userID=?", [commentID, myUserID])
        count = [row[0] for row in cur.fetchall()][0]
        print 'count=', count
        if count == 0:
            g.db.execute("INSERT INTO helpful (commentID, userID) VALUES (?, ?)", [commentID, myUserID])
            g.db.commit()
    
            # get old points
            cur = g.db.execute("SELECT points FROM comment WHERE commentID=?", [commentID])
            points = [row[0] for row in cur.fetchall()][0]
            print "oldPoints=", points
            points += 1
            print "newPoints:", points
            g.db.execute("UPDATE comment SET points=? WHERE commentID=?", [points, commentID])
            g.db.commit()
            return jsonify(result=1, points=points)
        else:
            return jsonify(result=2)



@app.route('/showAuthor/<authorID>', methods=['GET', 'POST'])
def showAuthor(authorID):
    author = db.getAnAuthor(authorID)
    books = db.getAutBooks(authorID)
    booknum = len(books)
    return render_template('showAuthor.html', author=author[0], books=books, booknum=booknum)


@app.route('/showUser/<userID>', methods=['GET', 'POST'])
def showUser(userID):
    print userID
    if session.get('logged_in') and userID == session['userID']:
        return redirect(url_for('myProfile'))
    else:
        user = db.getAUser(userID)
        comments = db.getUserComments(userID)
        books = db.getUserBook(userID)
        users = db.getUserUser(userID)
        return render_template('showUser.html', user=user[0], comments=comments, books=books, users=users)

@app.route('/myProfile', methods=['GET', 'POST'])
def myProfile():
    if not session.get('logged_in'):
        abort(401)
    myUserID = session['userID']
    print "userID in myProfile:", myUserID
    user = db.getAUser(myUserID)
    comments = db.getUserComments(myUserID)
    books = db.getUserBook(myUserID)
    users = db.getUserUser(myUserID)
    return render_template('myProfile.html', me=user[0], comments=comments, books=books, users=users)

@app.route('/editMyProfile', methods=['GET', 'POST'])
def editMyProfile():
    if not session.get('logged_in'):
        abort(401)
    myUserID = session['userID']
    user = db.getAUser(myUserID)
    comments = db.getUserComments(myUserID)
    books = db.getUserBook(myUserID)
    users = db.getUserUser(myUserID)
    if request.method == 'POST':
        # get email, pass, intro
        # update
        g.db.execute("UPDATE user SET email=?, user_password=?, introduction=? WHERE userID=?",
                     [request.form['email'].strip(), request.form['pass'].strip(), request.form['intro'].strip(), myUserID])
        g.db.commit()
        # get remove list (checkbox),
        booksToRemove = request.form.getlist('booksToRemove')
        usersToRemove = request.form.getlist('usersToRemove')
        print 'booksToRemove:', booksToRemove, '; usersToRemove:', usersToRemove
        # delete
        for b in booksToRemove:
            g.db.execute("DELETE FROM user_book WHERE userID=? AND bookID=?", [myUserID, b])
            g.db.commit()
        for u in usersToRemove:
            g.db.execute("DELETE FROM user_user WHERE userID1=? AND userID2=?", [myUserID, u])
            g.db.commit()
        flash("You have successfully updated your profile")
        return redirect(url_for('myProfile'))
    else:
        return render_template('editMyProfile.html', me=user[0], comments=comments, books=books, users=users)



@app.route('/editMyComment/<bookID>', methods=['GET', 'POST'])
def editMyComment(bookID):
    if not session.get('logged_in'):
        abort(401)
    myUserID = session['userID']
    print bookID, myUserID
    book = db.getABook(bookID)
    if request.method == 'POST':
        commentID = request.form['commentID']
        print commentID
        today = date.today()
        args = [ str(today), request.form['score'] ]
        columns = "comment_date=?, score=?"
        if request.form['cTitle']:
            args.append(request.form['cTitle'].strip())
            columns += ', comment_title=?'
        if request.form['cText']:
            args.append(request.form['cText'].strip())
            columns += ', comment_text=?'    
        # updateAComment
        args.append(commentID)
        print "UPDATE comment SET "+columns+" WHERE commentID=?"
        print args
        g.db.execute("UPDATE comment SET "+columns+" WHERE commentID=?", args)
        g.db.commit()
        myComment = db.getAComment(myUserID, bookID)
        flash("You have successfully updated your review")
        return render_template('addComment.html', book=book[0], myComment=myComment[0])
    else:
        myComment = db.getAComment(myUserID, bookID)
        return render_template('editMyComment.html', book=book[0], myComment=myComment[0])



@app.route('/addComment/<bookID>', methods=['GET', 'POST'])
def addComment(bookID):
    book = db.getABook(bookID)
    if not session.get('logged_in'):
        flash("You need to login first")
        return render_template('addComment.html', book=book[0], form=1)
    else: 
        myUserID = session['userID']
        myComment = db.getAComment(myUserID, bookID)
        if len(myComment) != 0:
            flash("You have already submitted a review for this book before")
            return render_template('addComment.html', book=book[0], myComment=myComment[0])
        elif request.method == 'POST':
            today = date.today()
            args = [ myUserID, bookID, str(today), 0, request.form['score'] ]
            columns = "userID, bookID, comment_date, points, score"
            values = "?, ?, ?, ?, ?"
            if request.form['cTitle']:
                args.append(request.form['cTitle'].strip())
                columns += ', comment_title'
                values += ', ?'
            if request.form['cText']:
                args.append(request.form['cText'].strip())
                columns += ', comment_text'
                values += ', ?'
            print columns
            print args
            db.add(table="comment", columns=columns, values=values, args=args)
            myComment = db.getAComment(myUserID, bookID)
            flash("You have successfully submitted a new review")
            return render_template('addComment.html', book=book[0], myComment=myComment[0])
        else:
            return render_template('addComment.html', book=book[0], form=1)




def sendEmail(email, message):
        msg = Message("Thank you for contacting us", sender='internetbookreviewdatabase@gmail.com', recipients=[email,'rithesh.shenthar@gmail.com','zhuyan@umd.edu'])
        msg.body = message
        mail.send(msg)
        print "Mail sent"


@app.route('/addBook', methods=['GET', 'POST'])
def addBook():
    publishers = db.getAllPublishers()
    categories = db.getAllCategories()
    if not session.get('logged_in'):
        flash("You need to login first")
        return render_template('addBook.html', publishers=publishers, categories=categories)
    else:
        myUserID = session['userID']
        if request.method == 'POST': # test if form is submitted
            title = request.form['title'].strip()
            author = request.form['authors'].strip()
            introduction = request.form['introduction'].strip()
            ISBN13 = request.form['ISBN13'].strip()
            pub_year = request.form['pub_year'].strip()
            pages = request.form['pages'].strip()

            columns = "userID, title, author, introduction, ISBN13, pub_year, pages"
            args = [myUserID, title, author, introduction, ISBN13, pub_year, pages]
    
            if request.form['publisherID'] == 'NA':
                args.append(request.form['publisherInput'].strip())
                columns += ', publisher'
            else:
                args.append(request.form['publisherID'])
                columns += ', publisherID'
            if request.form['categoryID'] == 'NA':
                args.append(request.form['categoryInput'].strip())
                columns += ', category'
            else:
                args.append(request.form['categoryID'])
                columns += ', categoryID'
    
            values = "?, ?"
            for i in range(2, len(args)):
                values += ', ?'
    
            print len(args), "; values", values, "\ncolumns: ", columns, "\nargs: ", args
            db.add(table="newbook", columns=columns, values=values, args=args)

            cur = g.db.execute('select last_insert_rowid()')
            newBookID = [row[0] for row in cur.fetchall()][0]
            cur = g.db.execute("select * from newbook where bookID=?", [newBookID])
            newbook = [dict(title=row[2], author=row[3], introduction=row[4], ISBN13=row[5], pub_year=row[6], pages=row[7]) for row in cur.fetchall()]
            print newbook
            
            user = db.getAUser(myUserID)
            print user[0]
            name = user[0]['name']
            email = user[0]['email']
            bookInfo = "Title: "+title+"\nAuthor(s): "+author+"\nIntroduction :"+introduction+"\nISBN13: "+ISBN13+"\nYear: "+pub_year+"\nPages: "+pages
            print bookInfo
            message = "From: IBDB <internetbookreviewdatabase@gmail.com>\nTo: "+name+" <"+email+">\nSubject: Thank you for contacting us\n\nWe have received your new book request.\n\n"+ bookInfo +"\n\nThank you,\nIBDB"
            print message
            sendEmail(email, message)
            flash("You have submitted a new book")
            return render_template('addBook.html', book=newbook[0], publishers=publishers, categories=categories)
        else:
            return render_template('addBook.html', publishers=publishers, categories=categories)



@app.route('/contact', methods=['GET','POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip()
        comments = request.form['comments'].strip()

        message = "From: IBDB <internetbookreviewdatabase@gmail.com>\nTo: "+name+" <"+email+">\nSubject: Thank you for contacting us\n\nWe have received your feedback.\n\n"+ comments +"\n\nThank you,\nIBDB"
        print message
        sendEmail(email, message)
        flash("You have submitted the form successfully. Thank you for your feedback!")

    return render_template('contact.html')


@app.route('/rss', methods=['GET','POST'])
def rss():
    return render_template('RSS.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        print "select user_password from user WHERE user_name='%s'" %(request.form['username'])
        cur = g.db.execute("select user_password, userID from user WHERE user_name='%s'" %(request.form['username']))
        rows = cur.fetchall()
        try:
            user_pwd = rows[0][0]
            userID = rows[0][1]
            print user_pwd, userID
            if request.form['password'] != user_pwd:
                error = 'Invalid password'
                print "user_pwd=", user_pwd
                print request.form['password']
            else:
                session['logged_in'] = True
                session['userID'] = userID
                print "userID in session:", session['userID']
                flash('You were logged in')
                return redirect(url_for('Home'))
        except:
            error = "Invalid Username"

    return render_template('login.html', error=error)


# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     error = None
#     if request.method == 'POST':
#         print "select user_password from user WHERE user_name='%s'" %(request.form['username'])
#         cur = g.db.execute("select user_password, userID from user WHERE user_name='%s'" %(request.form['username']))
#         rows = cur.fetchall()
#         user_pwd = rows[0][0]
#         userID = rows[0][1]
#         print user_pwd, userID
#         if bool(user_pwd) == False:
#             error = "Invalid Username"
#         if request.form['password'] != user_pwd:
#             error = 'Invalid password'
#             print "user_pwd=", user_pwd
#             print request.form['password']
#         else:
#             session['logged_in'] = True
#             session['userID'] = userID
#             print "userID in session:", session['userID']
#             flash('You were logged in')
#             return redirect(url_for('Home'))
#     return render_template('login.html', error=error)


@app.route('/register', methods=['GET', 'POST'])
def register():
    error = None
    if request.method == 'POST':
        # validation: what if the username is already in database
        cur = g.db.execute("select count(*) from user WHERE user_name='%s'" %(request.form['user_name']))
        count = [row[0] for row in cur.fetchall()][0]
        if count != 0 :
            error = "This username already exists! Please enter another one!"
        elif request.form['user_password'] != request.form['confirm']:
            error = 'Password and Confirm password are not the same'
        else:
            new_entry = request.form
            g.db = connect_db()
            column_list = ""
            value_list = ""
            for key in new_entry.keys():
                 if (key == 'confirm'):
                     continue
                 for value in new_entry.getlist(key):
                     if (isinstance( value, int )):
                         value_list += str(value)
                     else:
                         value_list += "'"+value+"'"
                     value_list += ","
                 column_list += key
                 column_list += ","

            print "insert into user (%s) values (%s)" %(column_list[:-1],value_list[:-1])
            g.db.execute("insert into user (%s) values (%s)" %(column_list[:-1],value_list[:-1]))
            g.db.commit()
            flash('New User entry was added successfully. Please log in.')
    return render_template('register.html',error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('You were logged out')
    return redirect(url_for('Home'))


if __name__ == '__main__':
    init_db()
    app.run()



